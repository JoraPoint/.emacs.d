#!/bin/bash

# захожу в виды фронта и очищаю файлы
cd /srv/http/yii/frontend/views/site/
rm -rf index.php about.php contact.php login.php signup.php
touch index.php about.php contact.php login.php signup.php
