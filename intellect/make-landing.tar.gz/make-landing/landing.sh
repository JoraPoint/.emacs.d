#!/bin/bash

#создаею проект yii-advanced руками

composer create-project --prefer-dist yiisoft/yii2-app-advanced yii

#захожу внутрь и заполняю .htaccess а далее следующими этапами можно проводить настройку магазина
cp one.txt ./yii/.htaccess
cp forback.txt ./yii/backend/web/.htaccess
cp forfront.txt ./yii/frontend/web/.htaccess
# перемещаю весь проект на локальный сервер
cp -r yii /srv/http/
# а местный убиваю
rm -Rf yii







