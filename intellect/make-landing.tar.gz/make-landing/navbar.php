<?php  
NavBar::begin([
    'brandLabel' => Yii::$app->name,
    'brandUrl' => Yii::$app->homeUrl,
    'options' => [
        'class' => 'layout_padding banner_section_start',
    ],
]);
$menuItems = [
    ['label' => 'Купить', 'url' => ['/site/index']],
    ['label' => 'Регистрация', 'url' => ['/site/index']],
    ['label' => 'Контакты', 'url' => ['/site/index']],
];
if (Yii::$app->user->isGuest) {
    $menuItems[] = ['label' => 'Войти', 'url' => ['/site/login']];
} else {
    $menuItems[] = '<li>'
                 . Html::beginForm(['/site/logout'], 'post')
                 . Html::submitButton(
                     'Logout (' . Yii::$app->user->identity->username . ')',
                     ['class' => 'container']
                 )
                 . Html::endForm()
                 . '</li>';
}
echo Nav::widget([
    'options' => ['class' => 'container'],
    'items' => $menuItems,
]);
NavBar::end();
?>
<!--
layout_padding banner_section_startlayout_padding banner_section_startcontainerlayout_padding banner_section_start


-->    
container
