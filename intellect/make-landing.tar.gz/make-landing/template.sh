#!/bin/bash

# делаю распакавку архива и затем архив удаляю
template=/home/egor/template
cd $template

# распаковка
find . -type f -name "*.zip" -exec unzip {} \;

# удаление
 find . -type f -name "*.zip" -exec rm -rf {} \;
# распределяю файлы шаблона в проект

local=/srv/http/yii
web=/srv/http/yii/web

# есть один момент - нужно удалить директорию css и выманить оттуда файл site.css чтобы потом его перезаписать
mv /srv/http/yii/frontend/web/css/site.css /srv/http/yii/frontend/web/
rm -rf /srv/http/yii/frontend/web/css

# нахожу новоявленную директорию
mydir=/home/egor/template/*

# если есть директория делаю разметку если нет вывожу ошибку
if [ -d $mydir ]
then
    cd $mydir
    cp -r $mydir/css /srv/http/yii/frontend/web/
    mv /srv/http/yii/frontend/web/site.css /srv/http/yii/frontend/web/css/site.css
    cp -r $mydir/js /srv/http/yii/frontend/web/
    cp -r $mydir/images /srv/http/yii/frontend/web/
    cp $mydir/index.html /srv/http/yii/frontend/web/ 
else
    echo "$this-> $mydir directory does not exist"
fi


