<?php

namespace backend\components;

use yii\base\Behavior;

    class Hammer extends Behavior
    {
        public $hammer = ' hammer attack!!!';

        public function hammerAttack()
        {
            return $this-> hammer;
        }
    }
