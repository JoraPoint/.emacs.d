<?php

namespace backend\controllers;

use Yii;
use backend\models\Suit;
use backend\models\Card;

/**
 * this controller for play game card
 * card being suit and card-name
 * example: diamonds jacke, diamonds - suit, jacke - name card
 *
 *
 * @return Yii
 *
 */
    class GameCardController extends \yii\web\Controller
    {
        public function actionIndex()
        {
            $this-> actionCard();
            $diamonds = Suit::find()->one()->getCard()->asArray()->all();
            foreach ($diamonds as $diamond)
            {
                echo $diamond['name_card'];
                echo '<br>'; 
            }
        }

        public function actionSuit()
        {
            $diamonds = new Suit;
            $diamonds -> id = 101;
            $diamonds -> name_suit = 'diamonds';
            $diamonds -> save();

            $hearts = new Suit;
            $hearts -> id = 202;
            $hearts -> name_suit = 'hearts';
            $hearts -> save();

            $clubs = new Suit;
            $clubs -> id = 303;
            $clubs -> name_suit = 'clubs';
            $clubs -> save();

            $spades = new Suit;
            $spades -> id = 404;
            $spades -> name_suit = 'spades';
            $spades -> save();
        }
        
        public function actionCard()
        {
            $dolly = new Card;
            $dolly -> name_card = 'Dolly';
            $dolly -> suit_id = 101;
            $dolly -> save();
        }
    }
