<?php

namespace backend\controllers;

use Yii;
use backend\models\Status;
use backend\models\Ork;

/**
 *
 *   controller for ork 
 *
 */
    class OrkController extends \yii\web\Controller
    {
        public function actionIndex()
        {
            $db = new \yii\db\ActiveQuery('ork');
            $db->createCommand('INSERT INTO `ork` (`name`, `status_id`) VALUES (:name, :status_id)', [
                ':name' => 'Dolly',
                ':status_id' => 202,
            ])->execute();
            
            $warriors = new Ork;
            $warriors -> warriors;
            echo '*****';
            echo '<br>'; 
            $magic = new Ork;
            $magic -> magic;
            
        }

        public function actionAdd()
        {
            $status = new Status;
            $status -> status = 'MegaMagic';
            $status -> save();

            $ork = new Ork;
            $ork -> name = 'Dolly';
            $ork -> save();

            $status -> link('ork', $ork);
        }

        public function actionMagic()
        {
            $status = Status::find()->where(['id' => 202])->one();

            $ork = new Ork;
            $ork -> name = 'Dolly';
            $ork -> save();

            $status -> link('ork', $ork);
        }
        
        public function actionStatus()
        {
            $warriors = new Status;
            $warriors -> id = 101;
            $warriors -> status = 'warriors';
            $warriors -> save();

            $magic = new Status;
            $magic -> id = 202;
            $magic -> status = 'magic';
            $magic -> save();
        }

    }
