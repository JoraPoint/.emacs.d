<?php

namespace backend\models;

use Yii;

/**
 * this is the model class for table card
 * 
 * @property int $id
 * @property string|null $name_card
 * @property int|null $id_suit 
 * 
 * @property Suit $suit
 */
    class Card extends \yii\db\ActiveRecord
    {
        /**
         *
         * {@inheritdoc} 
         *
         */
        public static function tableName()
        {
            return 'card';
        }

        /**
         *
         * {@inheritdoc}  
         *
         */
        public function rules()
        {
            return [
                [['suit_id'], 'integer'],
                [['name_card'], 'string', 'max' => 20],
                [['suit_id'], 'exist', 'skipOnError' => true, 'targetClass' => Suit::className(), 'targetAttribute' => ['suit_id' => 'id']],
            ];
        }

        /**
         *
         * {@inheritdoc} 
         *
         */
        public function attributeLabels()
        {
            return [
                'id' => 'ID',
                'name_card' => 'Name Your Card',
                'suit_id' => 'Id Suit',
            ];
        }

        /**
         * gets query for [[suit]]
         * @return \yii\db\ActiveQuery
         *
         */
        public function getSuit()
        {
            return $this-> hasOne(Suit::className(), ['suit_id' => 'id']); 
        }
    }
