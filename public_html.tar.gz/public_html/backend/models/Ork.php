<?php

namespace backend\models;

use Yii;

/**
 * this is the model class for table ork
 * @property int $id
 * @property string|null $name
 * @property int|null $status_id
 *
 */
    class Ork extends \yii\db\ActiveRecord
    {
        /**
         *
         *   this is Warriors
         *
         */
        const WARRIORS = 101;
        /**
         *
         *   this is Magic
         *
         */
        const MAGIC = 202;

        /* return name table */
        public static function tableName()
        {
            return 'ork';
        }

        /**
         *
         *   {@inheritdoc} 
         *
         */
        public function rules()
        {
            return [
                [['status_id'], 'integer'],
                [['name'], 'string', 'max' => 22],
                [['status_id'], 'exist', 'skipOnError' => true, 'targetClass' => Ork::className(), 'targetAttribute' => ['status_id' => 'id']],
            ];
        }

        /**
         *
         *   {@inheritdoc} 
         *
         */
        public function attributeLabels()
        {
            return [
                'id' => 'ID',
                'name' => 'Name Ork',
                'status_id' => 'Status Ork',
            ];
        }

        /**
         *
         *   gets query for ork
         *  @return \yii\db\ActiveQeury
         */
        public function getStatus()
        {
            return $this-> hasOne(Status::className(), ['id' => 'status_id']);
        }

        /**
         *
         *   показывает всех воинов
         *
         */
        public function getWarriors()
        {
            $query = (new \yii\db\Query)->from('ork')->where(['status_id' => self::WARRIORS]);
            // build and execute the query
            $rows = $query -> all();
            foreach ($rows as $row)
            {
                echo $row['name'];
                echo '<br>'; 
            }
        }

        /**
         *
         *   вызывает всех магов
         *
         */
        public static function getMagic()
        {
            $query = (new \yii\db\Query)->from('ork')->where(['status_id' => self::MAGIC]);
            $rows = $query->all();
            foreach ($rows as $row)
            {
                echo $row['name'];
                echo '<br>'; 
            }
        }
        
    }
  
