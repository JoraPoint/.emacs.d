<?php

namespace backend\models;

use Yii;

/**
 * status own orks or warriors or magic
 *
 */
    class Status extends \yii\db\ActiveRecord
    {
        /**
         *
         * table name 
         *
         */
        public static function tableName()
        {
            return 'status';
        }

        /**
         *
         *   rules for status
         *
         */
        public function rules()
        {
            return [
                [['status'], 'string', 'max' => 22],
            ];
        }

        /**
         *
         *   {@inheritdoc} 
         *
         */
        public function attributeLabels()
        {
            return [
                'id' => 'ID',
                'status' => 'Status your Ork',
            ];
        }

        /**
         *
         *   gets query for [[Ork]]
         * @return \yii\db\ActiveQuery
         */
        public function getOrk()
        {
            return $this-> hasMany(Ork::className(), ['status_id' => 'id']);  
        }
    }
