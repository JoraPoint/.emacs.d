<?php

namespace backend\models;

use Yii;
use yii\base\models;

/**
 * this is the model class for table suit
 * @property int $id
 * @property string|null $name_suit
 *
 * @property Card[]  $card
 *
 */
    class Suit extends \yii\db\ActiveRecord
    {
        /**
         *
         * {@inheritdoc} 
         *
         */
        public static function tableName()
        {
            return 'suit';
        }

        /**
         *
         * {@inheritdoc} 
         *
         */
        public function rules()
        {
            return [
                [['name_suit'], 'string', 'max' => 10],
            ];
        }

        /**
         *
         * {@inheritdoc} 
         *
         */
        public function attributeLabels()
        {
            return [
                'id' => 'ID',
                'name_suit' => 'Name Suit',
            ];
        }

        /**
         * gets qury for card
         * @return  \yii\db\ActiveQuery
         *
         */
        public function getCard()
        {
            return $this-> hasMany(Card::className(), ['suit_id' => 'id']);
        }
        
    }
