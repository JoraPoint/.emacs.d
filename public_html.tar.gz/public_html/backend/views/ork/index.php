<?php

\yii\helpers\VarDumper::dump($ork, 10, 2);
