<?php

\yii\helpers\VarDumper::dump($warriors, 10, 2);

echo ' твой уровень воина '. $warriors -> level;
