<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;


$robot = ActiveForm::begin();

echo $robot -> field($ork, 'name');
echo $robot -> field($ork, 'position');


echo Html::submitButton('WORK');

ActiveForm::end();

