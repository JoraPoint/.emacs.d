<?php

\yii\helpers\VarDumper::dump($cards, 10, 2);

foreach ($cards as $card)
{
    echo $card['name'];
    echo '<br>'; 
}

    
