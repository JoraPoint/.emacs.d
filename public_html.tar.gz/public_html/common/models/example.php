<?php

namespace frontend\models;

use Yii;
use yii\base\Model;

/**
 *
 * ContactForm is the model behind the contac form 
 *
 */
    class ContactForm extends Model
    {
        public $name;
        public $email;
        public $subject;
        public $body;
        public $verifyCode;

        /**
         *
         * iheritdoc 
         *
         */
        public function rules()
        {
            return [
                [['name', 'email', 'subject', 'body'], 'required'],
                ['email', 'email'],
                ['verifyCode', 'capthac'],
            ];
        }
        public function attributeLabels()
        {
            return [
                'varifyCode' => 'Verification Code',
            ];
        }

        /**
         * Sends an email to the/ specifided email address using the inforamtion collected by this model
         *
         * @param string $email $this-> target email address
         * @return bool whether the email was sendn

         *
         */
    }
