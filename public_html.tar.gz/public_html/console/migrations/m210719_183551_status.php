<?php

use yii\db\Migration;

/**
 * Class m210719_183551_status
 */
class m210719_183551_status extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this-> createTable('status', [
            'id' => $this-> primaryKey(),
            'status' => $this-> string(22),
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this-> dropTable('status');
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m210719_183551_status cannot be reverted.\n";

        return false;
    }
    */
}
