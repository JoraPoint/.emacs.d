<?php

use yii\db\Migration;

/**
 * Class m210719_183946_ork
 */
class m210719_183946_ork extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this-> createTable('ork', [
            'id' => $this-> primaryKey(),
            'name' => $this-> string(22),
            'status_id' => $this-> integer(22)
        ]);
        $this-> addForeignKey(
            'status_key',
            'ork',
            'status_id',
            'status',
            'id',
            'CASCADE'
        );
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this-> dropTable('ork');
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m210719_183946_ork cannot be reverted.\n";

        return false;
    }
    */
}
