<?php

namespace frontend\assets;

use yii\web\AssetBundle;

/**
 * Main frontend application asset bundle.
 */
class AppAsset extends AssetBundle
{
    public $basePath = '@webroot';
    public $baseUrl = '@web';
    public $css = [
        'css/ddsmoothmenu.css',
        'css/jquery.dualSlider.0.2.css',
        'css/slimbox2.css',
        'css/templatemo_style.css',
    ];
    public $js = [
        'js/ddsmoothmenu.js',
        'js/jquery.dualSlider.0.3.js',
        'js/jquery.dualSlider.0.3.min.js',
        'js/jquery.easing.1.3.js',
        'js/jquery.timers-1.2.js',
        'js/slimbox2.js',
    ];
    public $depends = [
        'yii\web\YiiAsset',
        'yii\bootstrap\BootstrapAsset',
    ];
}
